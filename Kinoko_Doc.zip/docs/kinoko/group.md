# 菌菌的邀请方式
菌菌需要加群申请才可以把她邀请去别的群。说是申请，其实条件很宽松：

> [!TIP] 具体条件
> - 群人数≥15，bot不计入人数
> - 群为音游相关群，最好是纯太鼓群

如果需要邀请，请加菌菌群，然后参考群公告的方式来申请吧！

## 菌菌群
以菌菌为中心的太鼓交流群，和别的太鼓群一样，日常聊天会比较多。也会在群里发表菌菌开发进度、周边制作进度等信息，**菌菌的所有图片稿件如表情包等都在群相册内。**

喜欢菌菌的话可以加群哦！~~喜欢我也行~~

你可以扫码或者点击[这个链接](http://qm.qq.com/cgi-bin/qm/qr?_wv=1027&k=tB6By6_4LsajTwtc-KcFwVUfFIzjspFM&authKey=Zk8hxRu3%2F39HkkYhhGhyt8yQla5b7Ib2EThCtM0BAuwGVORFA%2F%2BUnzgAb67nvOQP&noverify=0&group_code=873977020)来加群。

![帮助maimaiDX](/菌菌群.jpg)